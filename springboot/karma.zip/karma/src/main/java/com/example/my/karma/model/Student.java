package com.example.my.karma.model;

import jdk.nashorn.internal.objects.annotations.Setter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.sql.DataSourceDefinition;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {

    @Id
    private int stdid;
    private String Stdname;

    /*public String stdu(){*/
    /*    return this.stdid + this.Stdname;*/
    /*}*/
                                            /**/
}
