package com.example.my.karma.controller;

import com.example.my.karma.model.*;
import com.example.my.karma.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
public class karmaController {


    @Autowired
    private StudentService studentService;

    @RequestMapping("/home")
    public String hello(){
        return "hello world";
    }

    @RequestMapping("/students")
    public List<Student> add(){
        return studentService.getStudentss();
    }

    @RequestMapping("/search/{id}")
    public Student who(@PathVariable int id){

        return studentService.gethim(id);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/students")
    public String postt(@RequestBody Student s){
        studentService.addhim(s);

        return "added succesfully";


    }
    @RequestMapping(method= RequestMethod.POST , value="/update")
    public String upd(@RequestBody Student s){
        studentService.updatehim(s);
        return "update successfull";
    }

    @RequestMapping(method = RequestMethod.DELETE , value="/delete/{id}")
    public String deletehim(@PathVariable int id) {
        int flag = studentService.deletehim(id);
        //System.out.println(flag);
        if (flag==1) {
            return "delete successfull";
        } else {
            return "nothing there to delete";
        }


    }}
