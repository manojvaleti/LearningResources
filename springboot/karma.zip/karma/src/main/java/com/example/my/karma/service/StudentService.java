package com.example.my.karma.service;

import com.example.my.karma.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class StudentService {

    private List<Student> stu= new ArrayList<>
            (Arrays.asList(new Student(1,"hai") , new Student(2,"hello"),new Student(3,"who"),new Student(4,"who")
       ));

    public List<Student> getStudentss(){
        return stu;
    }
    public Student gethim(int id) {


        for (Student i : stu) {
            if (i.getStdid() == id) {
                return i;
            }
        }

        return new Student(0,"none");
    }

    public void addhim(Student s){
        stu.add(s);

    }

    public void updatehim(Student s){
        for(Student i : stu){
            if(i.getStdid()==s.getStdid()){
                i.setStdname(s.getStdname());

            }
        }
    }

    public int deletehim(int id){
        int j=0;
        for(Student i : stu){
           // System.out.println(j);
            if(i.getStdid()==id){
                stu.remove(i);
                j=1;
               break;

                //break;
            }
        }
        return j;
    }

}